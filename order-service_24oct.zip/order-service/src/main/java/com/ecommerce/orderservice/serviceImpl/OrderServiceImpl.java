

package com.ecommerce.orderservice.serviceImpl;

import com.ecommerce.orderservice.entity.Order;
import com.ecommerce.orderservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;    
import com.ecommerce.orderservice.dto.ProductDTO;
import com.ecommerce.orderservice.dto.UserDTO;
import com.ecommerce.orderservice.entity.OrderItem;
import com.ecommerce.orderservice.service.OrderService;
import org.springframework.web.client.RestTemplate;
  
import java.util.List;
  
@Service      
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

     @Autowired
    private RestTemplate restTemplate; 

    private static final String AUTH_SERVICE_URL = "http://auth-service";
    private static final String PRODUCT_SERVICE_URL = "http://product-service";
   

    @Override
    public Order createOrder(Order order) {
        // Fetch user details from auth-service
        UserDTO user = getUserDetails(order.getUser().getId());

        System.out.println("user "+ user );
        // Fetch product details for each order item
        for (OrderItem item : order.getItems()) {
            ProductDTO product = getProductDetails(item.getProduct().getId());
            item.setPrice(product.getPrice());    
        }

        // Set total price for the order
        double totalPrice = order.getItems().stream().mapToDouble(item -> item.getPrice() * item.getQuantity()).sum();
        order.setTotalPrice(totalPrice);

        System.out.println("order "+ order );

        // Save the order logic (using your repository)

        return order;
    }

    private UserDTO getUserDetails(Long userId) {
        // Call auth-service to fetch user details
        return restTemplate.getForObject(AUTH_SERVICE_URL + "/users/" + userId, UserDTO.class);
    }

    private ProductDTO getProductDetails(Long productId) {
        // Call product-service to fetch product details
        return restTemplate.getForObject(PRODUCT_SERVICE_URL + "/products/" + productId, ProductDTO.class);
    }


         
    @Override
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }        

    @Override
    public Order getOrderById(Long id) {
        return orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
    }

    @Override
    public Order updateOrderStatus(Long id, String status) {
        Order order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(status);
        return orderRepository.save(order); 
    }
}
