
package com.ecommerce.orderservice.service;
    
    
import com.ecommerce.orderservice.entity.Order;
import java.util.List;


public interface OrderService {

public Order createOrder(Order order);

 public List<Order> getAllOrders();

 public Order getOrderById(Long id);

 public Order updateOrderStatus(Long id, String status);

}   